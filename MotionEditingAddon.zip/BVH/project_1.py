import bpy
bvh_file = 'D:\Code\BlenderAddon/bvh_example/01.01.bvh'
bpy.ops.import_anim.bvh(filepath=bvh_file)

#print)bpy.data.objects["01_01"])